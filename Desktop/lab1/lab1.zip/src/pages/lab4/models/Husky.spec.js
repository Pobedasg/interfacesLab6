 import { Husky } from "../../src/pages/lab4/models/Husky";

describe("Husky Testing", () => {
  let husky;

  beforeEach(() => {
  // husky = require("../../src/pages/lab4/models/Husky.ts")
    husky = new Husky(120, 80);
  });

  fit("Створення екземпляру класу", () => {
    expect(husky).toBeTruthy();
  });
});
