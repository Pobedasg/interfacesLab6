import { Dog } from "./Dog";

 export class Taksa extends Dog  {
   mealCalculation(): number {
     return this.length * (1 / this.weight);
    
   }

   constructor(length: number, weigth: number) {
     super(length, weigth)
   }

}
